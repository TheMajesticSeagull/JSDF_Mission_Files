#define PREFIX JSDF
#define COMPONENT Mission

// Version
#define MAJOR 2
#define MINOR 3
#define PATCHLVL 1

#include "\x\cba\addons\main\script_macros_mission.hpp"
