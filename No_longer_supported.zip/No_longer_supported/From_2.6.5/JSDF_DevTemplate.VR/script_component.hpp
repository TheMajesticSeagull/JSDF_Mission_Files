#define PREFIX JSDF
#define COMPONENT Mission

// Version
#define MAJOR 2
#define MINOR 4
#define PATCHLVL "DEV"

#include "\x\cba\addons\main\script_macros_mission.hpp"
